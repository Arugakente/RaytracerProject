GOSSET Guillaume
LASOTA Quentin
Week number of assignment: 4

bin: contains the binary and the scenes, plus a batch script that produces each result
img: contains the result images and error images
src: contains every .cpp and .h file (+ the Makefile) at the end of the assignment, 
      plus the solution (.sln) file

bonuses :
 - bump mapping
 - gooch outlines (these outlines can be added to every rendermode)