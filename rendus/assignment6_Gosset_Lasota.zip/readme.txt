GOSSET Guillaume
LASOTA Quentin
Week number of assignment: 5

bin: contains the binary and the scenes, plus a batch script that produces each result
img: contains the result images and error images
src: contains every .cpp and .h file (+ the Makefile) at the end of the assignment, 
      plus the solution (.sln) file

bonuses :
 - Constructive solid geometry
 - Plane texture
(- alpha now impacts the shadows)

!!! WARNING - here is the computation time for our scenes !!! (in the batch order)
scene01-geometries   3 minutes
scene01-csg               4 minutes
scene01-csg-refract    4 minutes
scene01-obj-fast        1 hour
scene01-obj-csg         more than 1 hour
scene01-obj               multiple hours !!!