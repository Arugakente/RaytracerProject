GOSSET Guillaume
LASOTA Quentin
Week number of assignment: 2

bin: contains the binary and the scenes, plus a batch script that produces each result
img: contains the result images and error images
src: contains every .cpp and .h file (+ the Makefile) at the end of the assignment, 
      plus the solution (.sln) file

bonuses :
 - refraction implementation
 - old custom scene with reflection implementation
 - new custom scene with refraction implementation